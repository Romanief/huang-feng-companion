import {useId} from 'react';
export type PoseName='study'|'combat'|'rest'|'weary'|'cover'|'philosophy';
export const POSES:{id:PoseName;label:string;view:string;clip?:string}[]=[
 {id:'study',label:'Study',view:'20 15 405 535',clip:'M20 15H348V270H425V550H20Z'},
 {id:'combat',label:'Fighting',view:'360 50 670 465',clip:'M360 100L650 190V50H900L1030 200V515H455V295L545 272L360 160Z'},
 {id:'rest',label:'At rest',view:'1030 60 490 380'},
 {id:'weary',label:'Weary',view:'35 555 410 445'},
 {id:'cover',label:'In cover',view:'495 585 510 400'},
 {id:'philosophy',label:'Philosopher',view:'1035 435 470 565'},
];
export function CharacterPose({pose,className=''}:{pose:PoseName;className?:string}){const id=useId().replace(/:/g,'');const p=POSES.find(p=>p.id===pose)!;return <svg className={`character-pose ${className}`} viewBox={p.view} role="img" aria-label={`Huang Feng · ${p.label} pose from the supplied character reference`} preserveAspectRatio="xMidYMax meet" data-pose={pose}>{p.clip&&<defs><clipPath id={id}><path d={p.clip}/></clipPath></defs>}<image href={import.meta.env.BASE_URL+'assets/huang-feng-poses.png'} width="1536" height="1024" clipPath={p.clip?`url(#${id})`:undefined} style={{imageRendering:'pixelated'}}/></svg>;}
