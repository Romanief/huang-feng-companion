import {readdir,readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
async function walk(dir){let all=[];for(const f of await readdir(dir,{withFileTypes:true})){const p=`${dir}/${f.name}`;if(f.isDirectory())all.push(...await walk(p));else if(f.name!=='sw.js')all.push(p);}return all;}
const out=process.argv[2]||'dist';const files=await walk(out);const h=createHash('sha256');for(const f of files)h.update(await readFile(f));const version=h.digest('hex').slice(0,12);
await writeFile(`${out}/sw.js`,`const CACHE='silkwasp-${version}';const FILES=${JSON.stringify(files.map(x=>'./'+x.slice(out.length+1)))};
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener('message',e=>{if(e.data==='SKIP_WAITING')self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('silkwasp-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin)return;e.respondWith(caches.match(e.request,{ignoreVary:true}).then(hit=>hit||fetch(e.request).catch(()=>e.request.mode==='navigate'?caches.match(new URL('./index.html',self.registration.scope),{ignoreVary:true}):Response.error())))});`);
console.log('Offline shell precached:',files.length,'files; version',version);
