import {useEffect,useRef,useId,isValidElement,cloneElement,type ReactNode,type ReactElement} from 'react';
import {X, Dices} from './PixelIcons';
import {formula,signed,type DieSize,type RollResult} from '../dice';
export function Modal({title,children,onClose,wide=false,corner=true}:{title:string;children:ReactNode;onClose:()=>void;wide?:boolean;corner?:boolean}){
 const ref=useRef<HTMLDialogElement>(null),closeRef=useRef(onClose),titleId=useId();closeRef.current=onClose;
 useEffect(()=>{
  const d=ref.current!,layout=matchMedia('(min-width: 768px) and (min-height: 540px)');
  const show=()=>{const active=d.contains(document.activeElement)?document.activeElement as HTMLElement:null;if(d.open)d.close();const docked=corner&&layout.matches;d.dataset.docked=String(docked);d.setAttribute('aria-modal',String(!docked));if(docked)d.show();else d.showModal();active?.focus();};
  const escape=(e:KeyboardEvent)=>{if(e.key==='Escape'&&d.dataset.docked==='true'){e.preventDefault();closeRef.current();}};
  show();layout.addEventListener('change',show);document.addEventListener('keydown',escape);
  return()=>{layout.removeEventListener('change',show);document.removeEventListener('keydown',escape);d.close();};
 },[corner]);
 return <dialog ref={ref} aria-labelledby={titleId} className={`modal ${wide?'wide':''} ${corner?'corner-window':''}`} onCancel={e=>{e.preventDefault();onClose();}} onClick={e=>{if(e.target===e.currentTarget&&e.currentTarget.dataset.docked!=='true')onClose();}}><div className="modal-top"><h2 id={titleId}>{title}</h2><button className="icon-button" onClick={onClose} aria-label="Close dialog"><X size={20}/></button></div><div className="modal-body">{children}</div></dialog>;
}
export function Card({title,tag,children,className=''}:{title:string;tag?:string;children:ReactNode;className?:string}){return <section className={`card ${className}`}><div className="card-heading">{tag&&<span className="eyebrow">{tag}</span>}<h2>{title}</h2></div>{children}</section>;}
export function Field({label,children}:{label:string;children:ReactNode}){const id=useId();return <div className="field"><label htmlFor={id}>{label}</label>{isValidElement(children)?cloneElement(children as ReactElement<{id?:string}>,{id}):children}</div>;}
const DIE_GEOMETRY:Record<DieSize,{outline:string;facets:string}>={
 4:{outline:'32,4 60,56 4,56',facets:'M32 4V40L4 56M32 40L60 56'},
 6:{outline:'18,4 60,4 60,46 46,60 4,60 4,18',facets:'M4 18H46V60M46 18L60 4'},
 8:{outline:'32,2 60,32 32,62 4,32',facets:'M4 32L32 18L60 32M32 2V18M32 18V62'},
 10:{outline:'32,2 58,20 54,44 32,62 10,44 6,20',facets:'M32 2L40 30L32 62M6 20L40 30L58 20M10 44L40 30L54 44'},
 12:{outline:'20,2 44,2 62,22 56,48 32,62 8,48 2,22',facets:'M20 2L22 20L2 22M44 2L42 20L62 22M22 20H42L48 38L32 50L16 38ZM16 38L8 48M48 38L56 48M32 50V62'},
 20:{outline:'32,2 58,16 58,48 32,62 6,48 6,16',facets:'M6 16L22 18L32 2L42 18L58 16M6 48L18 44L6 16M58 48L46 44L58 16M22 18H42L46 44H18ZM22 18L18 44M42 18L46 44M18 44L32 62L46 44'},
};
export function PixelDie({sides}:{sides:DieSize}){const g=DIE_GEOMETRY[sides];return <svg className={`die-shape die-shape-${sides}`} viewBox="0 0 64 64" aria-hidden="true" shapeRendering="crispEdges"><polygon className="die-face" points={g.outline}/><path className="die-facets" d={g.facets}/></svg>;}
export function DiceResult({result,compact=false}:{result:RollResult;compact?:boolean}){return <div className={`dice-result ${compact?'compact':''}`} key={result.id}><div className="result-top"><span className="eyebrow">{result.source} {result.ability&&`· ${result.ability}`}</span><span>{result.mode==='normal'?'':result.mode}</span></div><div className="dice-line"><div className="die-tiles">{result.dice.map((d,i)=><div key={i} data-die={d.sides} className={`die-tile polyhedral-die ${d.kept?'':'discarded'}`}><small>d{d.sides}</small><div className="die-stage"><PixelDie sides={d.sides}/><strong>{d.replacement!==undefined?<><s>{d.raw}</s><span>{d.replacement}</span></>:d.raw}</strong></div><small>{d.replacement!==undefined?'LUCKY':d.kept?d.label:'dropped'}</small></div>)}</div><span className="equals">=</span><strong className="roll-total">{result.total}</strong></div><p className="roll-formula">{result.modifiers.map((m,i)=><span key={i}>{signed(m.value)} {m.label}{i<result.modifiers.length-1?' · ':''}</span>)}</p>{result.critical&&<span className="tag gold">CRITICAL HIT · DOUBLE DAMAGE DICE</span>}</div>;}
export function History({history,onClear}:{history:RollResult[];onClear:()=>void}){return <><div className="spread"><p>{history.length} saved rolls · newest first</p><button className="button subtle" onClick={onClear} disabled={!history.length}>Clear history</button></div>{history.length===0?<div className="empty"><Dices/><p>Your next roll will appear here.</p></div>:history.map(r=><article key={r.id} className="history-row"><div className="spread"><strong>{r.source}{r.ability&&` · ${r.ability}`}</strong><time dateTime={r.timestamp}>{new Date(r.timestamp).toLocaleString()}</time></div><p>{formula(r)}</p><div className="spread"><small>{r.kind} · {r.mode} · {r.randomSource}</small><strong className="gold-text">{r.total}{r.critical?' · critical hit':''}</strong></div></article>)}</>;}
