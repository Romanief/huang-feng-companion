import { ABILITIES, initialState, type State } from './model';
export const STORAGE_KEY='huang-feng-v1';
function object(v:unknown):v is Record<string,unknown>{return !!v&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v));}
const fail=(field:string):never=>{throw new Error(`Invalid save: ${field}`);};
function num(v:unknown,k:string,min:number,max:number):number{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)fail(k);return v as number;}
function str(v:unknown,k:string,max=50000):string{if(typeof v!=='string'||v.length>max)fail(k);return v as string;}
function bool(v:unknown,k:string):boolean{if(typeof v!=='boolean')fail(k);return v as boolean;}
function obj(v:unknown,k:string):Record<string,unknown>{if(!object(v))fail(k);return v as Record<string,unknown>;}
function strings(v:unknown,k:string,max=1000):string[]{if(!Array.isArray(v)||v.length>max)fail(k);return (v as unknown[]).map(x=>str(x,k));}
const modes=['normal','advantage','disadvantage'];
export function validateSave(input:unknown):State {
 const v=obj(input,'root');if(v.schemaVersion!==1)fail('unsupported schema version');const s=initialState();
 s.name=str(v.name,'name',200);s.savedAt=str(v.savedAt,'savedAt',100);if(!Number.isFinite(Date.parse(s.savedAt)))fail('savedAt');
 const abilities=obj(v.abilities,'abilities');for(const a of ABILITIES)s.abilities[a]=num(abilities[a],a,1,30);
 s.maxHp=num(v.maxHp,'maxHp',1,10000);s.hp=num(v.hp,'hp',0,s.maxHp);s.tempHp=num(v.tempHp,'tempHp',0,10000);s.hitDice=num(v.hitDice,'hitDice',0,9);
 s.robes=num(v.robes,'robes',0,5);s.ink=num(v.ink,'ink',0,4);s.deduction=num(v.deduction,'deduction',0,1);s.reactions=num(v.reactions,'reactions',0,2);
 const death=obj(v.death,'death');s.death={success:num(death.success,'death.success',0,3),failure:num(death.failure,'death.failure',0,3)};
 const tattoo=obj(v.tattoo,'tattoo');s.tattoo={available:bool(tattoo.available,'tattoo.available'),minutes:num(tattoo.minutes,'tattoo.minutes',0,60)};
 const f=obj(v.focus,'focus');s.focus={name:str(f.name,'focus.name',500),notes:str(f.notes,'focus.notes'),facts:{}};
 for(const [k,val] of Object.entries(obj(f.facts,'focus.facts'))){if(!['AC','Senses','Defences','Highest ability','Lowest ability','Trait / action','Alignment','Native plane','Spellcasting'].includes(k))fail('unknown Focus fact');s.focus.facts[k]=str(val,`focus.${k}`,10000);}
 s.combat=bool(v.combat,'combat');s.initiative=v.initiative===null?null:num(v.initiative,'initiative',-100,1000);s.round=num(v.round,'round',1,100000);s.turn=num(v.turn,'turn',0,100000);s.event=num(v.event,'event',1,1000000);s.studiedUsed=bool(v.studiedUsed,'studiedUsed');
 s.reactionEvents=strings(v.reactionEvents,'reactionEvents',100);s.conditions=strings(v.conditions,'conditions',30);
 if(!Array.isArray(v.effects)||v.effects.length>200)fail('effects');s.effects=(v.effects as unknown[]).map(x=>{const e=obj(x,'effect');return {id:str(e.id,'effect.id',200),target:str(e.target,'effect.target',500),name:str(e.name,'effect.name',500),detail:str(e.detail,'effect.detail',10000)};});
 for(const k of ['notes','contacts','inventory','itemNotes','customEffects','quickStudy'] as const)s[k]=str(v[k],k);
 const overrides=obj(v.overrides,'overrides');if(Object.keys(overrides).length>200)fail('overrides');s.overrides={};for(const [k,val] of Object.entries(overrides)){if(!/^(maxHp|ac|initiative|dc|speed|lock|save\.(STR|DEX|CON|INT|WIS|CHA)|skill\.[A-Za-z ]+|attack\.(Rapier|Light crossbow|Dagger)\.(focus|other)|damage\.(Rapier|Light crossbow|Dagger)\.(focus|other))$/.test(k))fail('override key');s.overrides[k]=num(val,`override ${k}`,k==='maxHp'?1:-100,k==='maxHp'?10000:1000);}
 const settings=obj(v.settings,'settings');if(!modes.includes(settings.mode as string))fail('roll mode');s.settings.mode=settings.mode as State['settings']['mode'];for(const k of ['mute','autoLucky','autoCheckCritical','incapacitationEndsFocus'] as const)s.settings[k]=bool(settings[k],k);
 s.lastBackup=v.lastBackup===null?null:str(v.lastBackup,'lastBackup',100);
 if(!Array.isArray(v.history)||v.history.length>500)fail('history');
 s.history=(v.history as unknown[]).map(x=>{
  const r=obj(x,'roll');const kind=str(r.kind,'roll.kind');if(!['ability','skill','save','initiative','attack','damage','healing','recharge','support'].includes(kind))fail('roll kind');if(!modes.includes(r.mode as string))fail('roll mode');
  if(!Array.isArray(r.dice)||r.dice.length>102)fail('roll dice');const dice=(r.dice as unknown[]).map(x=>{const d=obj(x,'die');const sides=num(d.sides,'sides',4,20);if(![4,6,8,10,12,20].includes(sides))fail('die sides');return {sides:sides as 4|6|8|10|12|20,label:str(d.label,'die label',200),raw:num(d.raw,'raw',1,sides),...(d.replacement===undefined?{}:{replacement:num(d.replacement,'replacement',1,sides)}),value:num(d.value,'value',1,sides),kept:bool(d.kept,'kept')};});
  if(!Array.isArray(r.modifiers)||r.modifiers.length>30)fail('modifiers');const modifiers=(r.modifiers as unknown[]).map(x=>{const m=obj(x,'modifier');return {label:str(m.label,'modifier.label',200),value:num(m.value,'modifier.value',-10000,10000)};});
  const total=num(r.total,'total',-100000,100000);if(total!==dice.filter(d=>d.kept).reduce((n,d)=>n+d.value,0)+modifiers.reduce((n,m)=>n+m.value,0))fail('roll total mismatch');
  return {id:str(r.id,'roll.id',200),timestamp:str(r.timestamp,'roll.timestamp',100),source:str(r.source,'roll.source',1000),kind:kind as State['history'][number]['kind'],...(r.ability===undefined?{}:{ability:str(r.ability,'roll.ability',200)}),mode:r.mode as State['settings']['mode'],dice,modifiers,total,...(r.natural===undefined?{}:{natural:num(r.natural,'natural',1,20)}),critical:bool(r.critical,'critical'),randomSource:str(r.randomSource,'randomSource',100)};
 });
 return s;
}
export function parseSave(text:string):State {if(text.length>3000000)throw new Error('Save exceeds 3 MB');const v=JSON.parse(text);return validateSave(v);}
export function migrate(input:unknown):State {
 // Explicit, narrow migration for a pre-release v0 save; never guesses at unknown versions.
 const v=obj(input,'root');if(v.schemaVersion===0){const s=initialState();s.hp=num(v.hp,'legacy HP',0,75);s.notes=str(v.notes??'','legacy notes');return validateSave({...s,savedAt:new Date().toISOString()});}return validateSave(v);
}
export function loadState(storage:Pick<Storage,'getItem'>):{state:State;error?:string;raw?:string} {
 let raw:string|null=null;try{raw=storage.getItem(STORAGE_KEY);if(raw)return {state:migrate(JSON.parse(raw))};const old=storage.getItem('huang-feng-v0');return {state:old?migrate(JSON.parse(old)):initialState()};}catch(e){return {state:initialState(),error:`Your saved data could not be loaded. It has not been overwritten. ${e instanceof Error?e.message:'Storage unavailable'}`,raw:raw??undefined};}
}
export function saveState(storage:Pick<Storage,'setItem'>,s:State){const value={...s,savedAt:new Date().toISOString(),history:s.history.slice(0,500)};storage.setItem(STORAGE_KEY,JSON.stringify(value));return value;}
export function downloadSave(s:State,filename='huang-feng-save.json'){const url=URL.createObjectURL(new Blob([JSON.stringify(s,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
