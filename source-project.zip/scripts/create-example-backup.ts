import {writeFileSync} from 'node:fs';
import {initialState} from '../src/model';
import {validateSave} from '../src/storage';
const example=validateSave(initialState());
writeFileSync('examples/huang-feng-canon-level-9.json',JSON.stringify(example,null,2)+'\n');
