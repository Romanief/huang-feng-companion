import test from 'node:test';
import assert from 'node:assert/strict';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {CharacterSheet} from '../src/components/CharacterSheet';
import {ReactionDialog,RopeDialog} from '../src/components/AbilityDialogs';
import {initialState} from '../src/model';
const noop=()=>{};
test('Rendered level-10 sheet and equipment use the same overridden DC',()=>{
 const state={...initialState(),overrides:{dc:19}};
 const html=renderToStaticMarkup(createElement(CharacterSheet,{state,saved:true,transition:false,onChange:noop,open:noop,onCheck:noop,onSave:noop,onSkill:noop,onLock:noop,onInitiative:noop,onEndCombat:noop,onTurn:noop,onCreatureTurn:noop,onExport:noop,onMute:noop,brave:false,setBrave:noop,extraplanar:false,setExtraplanar:noop,hp:null,resources:null,focus:null,rest:null,settings:null,tools:null}));
 assert.match(html,/Savant 10/);assert.match(html,/Unrivaled Genius/);assert.match(html,/DEX DC 19/);assert.match(html,/STR or DEX DC 19/);assert.doesNotMatch(html,/DC 15|DC 17|SAVANT 9|level 9|No movement or counterattack/);
});
test('Rendered dialogs expose non-Focus support and matching item DC without spending resources',()=>{
 const state={...initialState(),overrides:{dc:18}},props={state,onChange:noop,onRoll:()=>{throw new Error('Inspecting must not roll');},onEffect:noop};
 const observation=renderToStaticMarkup(createElement(ReactionDialog,{...props,name:'Potent Observation'}));
 assert.match(observation,/damage against another target/);assert.match(observation,/keep only the highest/);assert.match(observation,/Never an attack roll bonus/);
 const rope=renderToStaticMarkup(createElement(RopeDialog,props));assert.match(rope,/DEX DC 18/);assert.match(rope,/STR or DEX DC 18/);assert.doesNotMatch(rope,/DC 15/);assert.equal(state.reactions,2);assert.equal(state.ink,4);
});
