import type { RollResult, RollMode } from './dice';
export const ABILITIES = ['STR','DEX','CON','INT','WIS','CHA'] as const;
export type Ability = typeof ABILITIES[number];
export const SKILLS: { name:string; ability:Ability; proficiency:number; intellect?:boolean; item?:number }[] = [
 {name:'Acrobatics',ability:'DEX',proficiency:0},{name:'Animal Handling',ability:'WIS',proficiency:0},{name:'Arcana',ability:'INT',proficiency:1,intellect:true},
 {name:'Athletics',ability:'STR',proficiency:0},{name:'Deception',ability:'CHA',proficiency:1},{name:'History',ability:'INT',proficiency:1},
 {name:'Insight',ability:'WIS',proficiency:1},{name:'Intimidation',ability:'CHA',proficiency:0},{name:'Investigation',ability:'INT',proficiency:1,intellect:true},
 {name:'Medicine',ability:'WIS',proficiency:0},{name:'Nature',ability:'INT',proficiency:0},{name:'Perception',ability:'WIS',proficiency:1},
 {name:'Performance',ability:'CHA',proficiency:0},{name:'Persuasion',ability:'CHA',proficiency:0},{name:'Religion',ability:'INT',proficiency:1,intellect:true},
 {name:'Sleight of Hand',ability:'DEX',proficiency:0,item:5},{name:'Stealth',ability:'DEX',proficiency:2},{name:'Survival',ability:'WIS',proficiency:0}
];
export type Effect = {id:string;target:string;name:string;detail:string};
export type State = {
 schemaVersion:1; savedAt:string; name:string; abilities:Record<Ability,number>; maxHp:number; overrides:Record<string,number>;
 hp:number; tempHp:number; hitDice:number; death:{success:number;failure:number}; robes:number; ink:number; deduction:number;
 tattoo:{available:boolean;minutes:number}; focus:{name:string;facts:Record<string,string>;notes:string};
 combat:boolean; initiative:number|null; round:number; turn:number; reactions:number; studiedUsed:boolean;
 event:number; reactionEvents:string[]; conditions:string[]; effects:Effect[];
 notes:string; contacts:string; inventory:string; itemNotes:string; customEffects:string; quickStudy:string;
 history:RollResult[]; settings:{mode:RollMode;mute:boolean;autoLucky:boolean;autoCheckCritical:boolean;incapacitationEndsFocus:boolean;};
 lastBackup:string|null;
};
export const INITIAL_INVENTORY='Blade of the Scribe +2 (attuned)\nDoctoral Robes (attuned)\nBoots of Striding and Springing (attuned)\nRope of Entanglement\nGloves of Thievery\nSpellwrought Tattoo: Longstrider (single use; see tracker)\nDagger\nLight crossbow · 20 bolts (starting quantity; update after use)\nCobbler’s Tools · Scholar’s Pack\nLeather armour (stored)\nCrowbar · dark hooded common clothes\n15 gp (starting currency; update after play)\nThieves’ Tools / Dragonchess set: possession to confirm with DM';
export function initialState():State { return {schemaVersion:1,savedAt:new Date().toISOString(),name:'Huang Feng',abilities:{STR:8,DEX:14,CON:16,INT:20,WIS:10,CHA:8},maxHp:75,overrides:{},hp:75,tempHp:0,hitDice:9,death:{success:0,failure:0},robes:5,ink:4,deduction:1,tattoo:{available:true,minutes:0},focus:{name:'',facts:{},notes:''},combat:false,initiative:null,round:1,turn:0,reactions:2,studiedUsed:false,event:1,reactionEvents:[],conditions:[],effects:[],notes:'',contacts:'Parents · both about 106; help the resistance with food, repairs and supplies.\nUnderground resistance contacts · Criminal Contact (Spy).',inventory:INITIAL_INVENTORY,itemNotes:'',customEffects:'',quickStudy:'',history:[],settings:{mode:'normal',mute:true,autoLucky:true,autoCheckCritical:false,incapacitationEndsFocus:false},lastBackup:null}; }
export const mod=(score:number)=>Math.floor((score-10)/2);
export const incapacitated=(s:State)=>s.conditions.some(x=>['Incapacitated','Unconscious','Paralyzed','Petrified','Stunned'].includes(x));
export function derived(s:State){
 const m=Object.fromEntries(ABILITIES.map(a=>[a,mod(s.abilities[a])])) as Record<Ability,number>;
 const ov=(k:string,n:number)=>s.overrides[k]??n;
 const saves=Object.fromEntries(ABILITIES.map(a=>[a,ov(`save.${a}`,m[a]+m.INT+(['INT','WIS'].includes(a)?4:0))])) as Record<Ability,number>;
 const skills=Object.fromEntries(SKILLS.map(k=>[k.name,ov(`skill.${k.name}`,m[k.ability]+Math.max(k.proficiency,s.quickStudy===k.name?1:0)*4+(k.item||0))]));
 return {m,saves,skills,ac:ov('ac',15+m.INT),initiative:ov('initiative',m.DEX+(incapacitated(s)?0:m.INT)),dc:ov('dc',12+m.INT),speed:ov('speed',30)+(s.tattoo.minutes>0?10:0),lock:ov('lock',m.DEX+4+5),robesMax:5,pb:4,intellect:8};
}
export type Weapon = 'Rapier'|'Light crossbow'|'Dagger';
export function weaponStats(s:State,weapon:Weapon,focus:boolean){const d=derived(s),magic=weapon==='Rapier'?2:0,ability=focus?d.m.INT:d.m.DEX;return {attack:s.overrides[`attack.${weapon}.${focus?'focus':'other'}`]??ability+4+magic,damage:s.overrides[`damage.${weapon}.${focus?'focus':'other'}`]??ability+magic,sides:weapon==='Dagger'?4 as const:8 as const,range:weapon==='Rapier'?'5 ft · finesse':weapon==='Light crossbow'?'80/320 ft · ammunition, loading':'5 ft / thrown 20/60 ft'};}
export function startTurn(s:State,nextRound=false):State{return {...s,round:s.round+(nextRound?1:0),turn:s.turn+1,reactions:2,studiedUsed:false,reactionEvents:[],event:s.event+1};}
export function enterCombat(s:State,initiative:number):State {return s.combat?{...s,initiative}:{...startTurn(s),combat:true,initiative,round:1};}
export const endCombat=(s:State):State=>({...s,combat:false});
export function longRest(s:State):State{return {...s,hp:s.maxHp,tempHp:0,hitDice:Math.min(9,s.hitDice+4),robes:5,deduction:1,death:{success:0,failure:0}};}
export function shortRest(s:State,results:RollResult[]):State {if(results.length>s.hitDice)throw new Error('Not enough Hit Dice');return {...s,hp:Math.min(s.maxHp,s.hp+results.reduce((n,r)=>n+Math.max(0,r.total),0)),hitDice:s.hitDice-results.length};}
export function dawn(s:State,recharge:number):State {return {...s,ink:Math.min(4,s.ink+recharge)};}
export function spendReaction(s:State,eventKey:string,robes=false):State {if(incapacitated(s))throw new Error('Cannot take reactions while incapacitated');if(s.reactions<1)throw new Error('No reactions remain');if(s.reactionEvents.includes(eventKey))throw new Error('One reaction per triggering event. Start a new event for a different trigger.');if(robes&&s.robes<1)throw new Error('No Robes charges remain');return {...s,reactions:s.reactions-1,robes:s.robes-(robes?1:0),reactionEvents:[...s.reactionEvents,eventKey]};}
export function useInk(s:State,successfulHit:boolean,confirmed:boolean):State {if(!successfulHit||!confirmed)throw new Error('Ink requires a confirmed successful rapier hit');if(s.ink<1)throw new Error('No ink charges remain');return {...s,ink:s.ink-1};}
export function applyDamage(s:State,amount:number):State {const absorbed=Math.min(s.tempHp,amount);return {...s,tempHp:s.tempHp-absorbed,hp:Math.max(0,s.hp-(amount-absorbed))};}

export function changeAbility(s:State,ability:Ability,value:number):State {const score=Math.max(1,Math.min(30,Math.round(value)||1));const maxHp=ability==='CON'?(s.overrides.maxHp??Math.max(1,s.maxHp+9*(mod(score)-mod(s.abilities.CON)))):s.maxHp;return {...s,abilities:{...s.abilities,[ability]:score},maxHp,hp:Math.min(s.hp,maxHp)};}
