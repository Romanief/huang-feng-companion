export type RollMode = 'normal' | 'advantage' | 'disadvantage';
export type RollKind = 'ability' | 'skill' | 'save' | 'initiative' | 'attack' | 'damage' | 'healing' | 'recharge' | 'support';
export type DieSize = 4 | 6 | 8 | 10 | 12 | 20;
export type DieGroup = { count: number; sides: DieSize; label: string; keepHighest?:boolean };
export type RollSpec = { source: string; kind: RollKind; ability?: string; modifier?: number; modifiers?: {label:string;value:number}[]; groups?: DieGroup[]; mode?: RollMode; lucky?: boolean };
export type DieResult = { sides: DieSize; label: string; raw: number; replacement?: number; value: number; kept: boolean };
export type RollResult = { id: string; timestamp: string; source: string; kind: RollKind; ability?: string; mode: RollMode; dice: DieResult[]; modifiers: {label:string;value:number}[]; total: number; natural?: number; critical: boolean; randomSource: string };
export type RandomDie = (sides: number) => number;
let fallbackUsed = false;
export const randomDie: RandomDie = sides => {
 if (!Number.isInteger(sides) || sides < 2 || sides > 1000) throw new Error('Invalid die');
 if (typeof globalThis.crypto !== 'undefined' && typeof globalThis.crypto.getRandomValues === 'function') {
  const limit = Math.floor(0x100000000 / sides) * sides; const a = new Uint32Array(1);
  do { crypto.getRandomValues(a); } while (a[0] >= limit);
  return (a[0] % sides) + 1;
 }
 fallbackUsed = true; return Math.floor(Math.random() * sides) + 1;
};
const d20Kinds: RollKind[] = ['ability','skill','save','initiative','attack'];
export function roll(spec: RollSpec, rng: RandomDie = randomDie): RollResult {
 const dice: DieResult[] = []; const isD20 = d20Kinds.includes(spec.kind); const mode = isD20 ? spec.mode || 'normal' : 'normal';
 const draw = (sides: DieSize) => { const n=rng(sides); if(!Number.isInteger(n)||n<1||n>sides) throw new Error('Random source returned an invalid die'); return n; };
 if (isD20) {
  for(let i=0; i<(mode==='normal'?1:2);i++) {
   const raw=draw(20); const replacement=spec.lucky!==false&&raw===1?draw(20):undefined;
   dice.push({sides:20,label:'d20',raw,...(replacement===undefined?{}:{replacement}),value:replacement??raw,kept:true});
  }
  if(dice.length===2){ const keep=mode==='advantage'?(dice[1].value>dice[0].value?1:0):(dice[1].value<dice[0].value?1:0); dice.forEach((d,i)=>d.kept=i===keep); }
 }
 for(const group of spec.groups||[]){
  if(!Number.isInteger(group.count)||group.count<0||group.count>100) throw new Error('Invalid dice count');
  const start=dice.length; for(let i=0;i<group.count;i++){const raw=draw(group.sides);dice.push({sides:group.sides,label:group.label,raw,value:raw,kept:true});} if(group.keepHighest && group.count>1){const max=Math.max(...dice.slice(start).map(d=>d.value));let found=false;dice.slice(start).forEach(d=>{d.kept=!found&&d.value===max;if(d.kept)found=true;});}
 }
 const modifiers=spec.modifiers??[{label:'Fixed modifier',value:spec.modifier||0}];
 const natural=isD20?dice.find(d=>d.sides===20&&d.kept)?.value:undefined;
 return {id:globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random()}`,timestamp:new Date().toISOString(),source:spec.source,kind:spec.kind,...(spec.ability===undefined?{}:{ability:spec.ability}),mode,dice,modifiers,total:dice.filter(d=>d.kept).reduce((n,d)=>n+d.value,0)+modifiers.reduce((n,m)=>n+m.value,0),...(natural===undefined?{}:{natural}),critical:spec.kind==='attack'&&natural===20,randomSource:fallbackUsed?'Math.random fallback':'Web Crypto'};
}
export const signed=(n:number)=>n>=0?`+${n}`:`${n}`;
export const formula=(r:RollResult)=>r.dice.map(d=>`${d.kept?'':'['}d${d.sides} ${d.raw}${d.replacement!==undefined?` → ${d.replacement} (Lucky)`:''}${d.kept?'':']'}`).join(' + ')+r.modifiers.map(m=>` ${signed(m.value)} ${m.label}`).join('');
