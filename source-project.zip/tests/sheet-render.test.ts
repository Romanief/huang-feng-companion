import test from 'node:test';
import assert from 'node:assert/strict';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {CharacterSheet} from '../src/components/CharacterSheet';
import {ReactionDialog,RopeDialog} from '../src/components/AbilityDialogs';
import {AttackDialog,SpiderbiteRider} from '../src/components/AttackDialog';
import {FocusEditor} from '../src/components/FocusPanel';
import {Settings} from '../src/components/Settings';
import {initialState} from '../src/model';
const noop=()=>{};
test('Rendered level-10 sheet and equipment use the same overridden DC',()=>{
 const state={...initialState(),overrides:{dc:19}};
 const html=renderToStaticMarkup(createElement(CharacterSheet,{state,saved:true,transition:false,onChange:noop,open:noop,onCheck:noop,onSave:noop,onSkill:noop,onLock:noop,onInitiative:noop,onEndCombat:noop,onTurn:noop,onCreatureTurn:noop,onExport:noop,onMute:noop,brave:false,setBrave:noop,extraplanar:false,setExtraplanar:noop,hp:null,resources:null,focus:null,rest:null,settings:null,tools:null}));
 assert.match(html,/Savant 10/);assert.match(html,/Unrivaled Genius/);assert.match(html,/DEX DC 19/);assert.match(html,/STR or DEX DC 19/);assert.doesNotMatch(html,/DC 15|DC 17|SAVANT 9|level 9|No movement or counterattack/);
});
test('Rendered dialogs expose non-Focus support and matching item DC without spending resources',()=>{
 const state={...initialState(),overrides:{dc:18}},props={state,onChange:noop,onRoll:()=>{throw new Error('Inspecting must not roll');},onEffect:noop};
 const observation=renderToStaticMarkup(createElement(ReactionDialog,{...props,name:'Potent Observation'}));
 assert.match(observation,/damage against another target/);assert.match(observation,/2d8, add both results/);assert.match(observation,/<option>damage against my Focus<\/option>/);assert.match(observation,/Never an attack roll bonus/);
 const rope=renderToStaticMarkup(createElement(RopeDialog,props));assert.match(rope,/DEX DC 18/);assert.match(rope,/STR or DEX DC 18/);assert.doesNotMatch(rope,/DC 15/);assert.equal(state.reactions,2);assert.equal(state.ink,4);
});

test('Focus can be selected in ordinary and counterattacks with no tracked name',()=>{
 const state=initialState(),props={state,weapon:'Rapier' as const,onChange:noop,onRoll:()=>{throw new Error('Inspection must not roll');},onEffect:noop};
 for(const reactionAttack of [false,true]){
  const html=renderToStaticMarkup(createElement(AttackDialog,{...props,reactionAttack}));
  assert.match(html,/<option value="focus">Focus · name optional<\/option>/);assert.doesNotMatch(html,/<option value="focus"[^>]*disabled/);
 }
 const editor=renderToStaticMarkup(createElement(FocusEditor,{state,onSave:noop,onClose:noop}));assert.match(editor,/Focus name \(optional\)/);assert.doesNotMatch(editor,/<button[^>]*disabled[^>]*>Confirm Focus/);
});
test('Settings no longer contain the Focus dice interpretation toggle',()=>{
 const html=renderToStaticMarkup(createElement(Settings,{state:initialState(),onChange:noop,onExport:noop,onImport:noop,onCanon:noop,installStatus:'Available'}));
 assert.doesNotMatch(html,/potentFocusSum|otherwise keep highest|Potent Observation dice/);
});

test('Rendered current sheet and settings show INT22, its maximum and updated Robes bonus',()=>{
 const state=initialState();const html=renderToStaticMarkup(createElement(CharacterSheet,{state,saved:true,transition:false,onChange:noop,open:noop,onCheck:noop,onSave:noop,onSkill:noop,onLock:noop,onInitiative:noop,onEndCombat:noop,onTurn:noop,onCreatureTurn:noop,onExport:noop,onMute:noop,brave:false,setBrave:noop,extraplanar:false,setExtraplanar:noop,hp:null,resources:null,focus:null,rest:null,settings:null,tools:null}));
 assert.match(html,/INT save \+16 \+ d8/);assert.match(html,/WIS save \+10 \+ d8/);assert.match(html,/CHA save \+5 \+ d8/);assert.match(html,/Tome of Clear Thought/);assert.match(html,/add \+6 \(INT\)/);assert.match(html,/DEX DC 18/);
 const settings=renderToStaticMarkup(createElement(Settings,{state,onChange:noop,onExport:noop,onImport:noop,onCanon:noop,installStatus:'Available'}));assert.match(settings,/permanent Intelligence maximum 22/);assert.match(settings,/value="22"/);
});

test('Rendered sheet replaces the ordinary dagger and offers the off-hand bonus attack',()=>{
 const state=initialState();const html=renderToStaticMarkup(createElement(CharacterSheet,{state,saved:true,transition:false,onChange:noop,open:noop,onCheck:noop,onSave:noop,onSkill:noop,onLock:noop,onInitiative:noop,onEndCombat:noop,onTurn:noop,onCreatureTurn:noop,onExport:noop,onMute:noop,brave:false,setBrave:noop,extraplanar:false,setExtraplanar:noop,hp:null,resources:null,focus:null,rest:null,settings:null,tools:null}));
 assert.match(html,/Spiderbite Daggers/);assert.match(html,/Off-hand Spiderbite/);assert.doesNotMatch(html,/<strong>Dagger<\/strong>/);assert.match(html,/CON DC 18/);
});
test('Off-hand dialog shows correct action,1d4+0, and light-weapon rule without disabling unnamed Focus',()=>{
 const props={state:initialState(),weapon:'Spiderbite Daggers' as const,offHand:true,onChange:noop,onRoll:()=>{throw new Error('Inspecting must not roll');},onEffect:noop};
 const html=renderToStaticMarkup(createElement(AttackDialog,props));assert.match(html,/BONUS ACTION · OFF-HAND ATTACK/);assert.match(html,/1d4\+0/);assert.match(html,/rapier is not light/);assert.match(html,/<option value="focus">Focus · name optional<\/option>/);
 const rider=renderToStaticMarkup(createElement(SpiderbiteRider,{...props,targetName:'Unnamed Focus'}));assert.match(rider,/Both daggers hit this target on my turn/);assert.doesNotMatch(rider,/Roll 2d4 poison|Save FAILURE/);assert.match(rider,/CON DC 18/);
});
