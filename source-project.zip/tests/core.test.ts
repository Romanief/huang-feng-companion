import test from 'node:test';
import assert from 'node:assert/strict';
import {roll,randomDie,type RollSpec} from '../src/dice';
import {initialState,derived,weaponStats,useInk,spendReaction,shortRest,longRest,dawn,enterCombat,endCombat,startTurn,applyDamage,incapacitated,SKILLS,changeAbility,observationSpec,effectText,spiderbitePoisonSpec,equipSpiderbiteDaggers} from '../src/model';
import {validateSave,parseSave,loadState,saveState,migrate,STORAGE_KEY} from '../src/storage';
import {WORDS,FEATURES,itemsFor,featuresFor} from '../src/rules';
const sequence=(...values:number[])=>{let i=0;return (sides:number)=>{assert.ok(i<values.length,'unexpected extra random draw');const v=values[i++];assert.ok(v<=sides);return v;};};
const s=initialState();
test('1 · canonical level 10 statistics',()=>{const d=derived(s);assert.deepEqual([s.maxHp,d.ac,d.initiative,d.pb,d.intellect,d.dc,d.speed,s.reactions],[83,21,8,4,8,18,30,2]);assert.equal(derived({...s,tattoo:{available:false,minutes:60}}).speed,40);});
test('2 · all six exact saves, mental d8 separate',()=>{assert.deepEqual(derived(s).saves,{STR:5,DEX:8,CON:9,INT:16,WIS:10,CHA:5});for(const a of ['INT','WIS','CHA'] as const){const r=roll({source:a,kind:'save',modifier:derived(s).saves[a],groups:[{count:1,sides:8,label:'Sharp Mind'}]},sequence(10,6));assert.equal(r.total,16+derived(s).saves[a]);assert.equal(r.dice.length,2);}});
test('3 · skills, Gloves and lockpicking totals',()=>{const d=derived(s);assert.equal(SKILLS.length,18);assert.deepEqual([d.skills.Stealth,d.skills.Investigation,d.skills.Arcana,d.skills['Sleight of Hand'],d.lock],[10,10,10,7,11]);assert.equal(derived({...s,quickStudy:'Sleight of Hand'}).skills['Sleight of Hand'],11);});
test('4 · Focus and non-Focus weapons, no Extra Attack',()=>{assert.deepEqual([weaponStats(s,'Rapier',true).attack,weaponStats(s,'Rapier',true).damage],[12,8]);assert.deepEqual([weaponStats(s,'Rapier',false).attack,weaponStats(s,'Rapier',false).damage],[8,4]);assert.deepEqual([weaponStats(s,'Light crossbow',true).attack,weaponStats(s,'Light crossbow',false).attack],[10,6]);assert.deepEqual([weaponStats(s,'Spiderbite Daggers',true).damage,weaponStats(s,'Spiderbite Daggers',false).damage],[6,2]);assert.ok(FEATURES.find(f=>f.name==='Studied Strike')!.text.includes('no Extra Attack'));});
test('5 · ink requires successful hit and explicit confirmation',()=>{assert.throws(()=>useInk(s,false,true));assert.throws(()=>useInk(s,true,false));assert.equal(useInk(s,true,true).ink,3);assert.equal(derived(s).dc,18);assert.throws(()=>useInk({...s,ink:0},true,true));});
test('6 · Robes consumes both resources; only long rest refills',()=>{const a=spendReaction(s,'attack-1',true);assert.deepEqual([a.robes,a.reactions],[4,1]);assert.equal(shortRest(a,[]).robes,4);assert.equal(longRest(a).robes,5);});
test('7 · level-10 Observation supports any target, two dice only against Focus',()=>{
 const focused={...s,focus:{name:'Target',facts:{},notes:''}};
 for(const kind of ['saving throw','damage against another target','skill/tool check I am proficient in'] as const){const spec=observationSpec(focused,kind);assert.equal(spec.groups![0].count,1);assert.equal(roll(spec,sequence(6)).total,6);}
 const spec=observationSpec(focused,'damage against my Focus');assert.equal(spec.groups![0].count,2);const summed=roll(spec,sequence(3,7));assert.equal(summed.total,10);assert.ok(summed.dice.every(d=>d.kept));
 const unnamed=roll(observationSpec(s,'damage against my Focus'),sequence(2,8));assert.equal(unnamed.total,10);assert.match(unnamed.source,/Unnamed Focus/);assert.match(FEATURES.find(f=>f.name==='Potent Observation')!.text,/No attack roll bonus/);
});
test('8 · Unrivaled Genius permits a single follow-up only if Flourish causes a miss',()=>{const text=FEATURES.find(f=>f.name==='Calculated Flourish')!.text;assert.match(text,/if the attack misses/);assert.match(text,/10-foot move/);assert.match(text,/one weapon attack against your attacker/);assert.ok(FEATURES.some(f=>f.level===10&&f.name==='Unrivaled Genius'));assert.ok(!FEATURES.some(f=>f.level>10));});
test('9 · level-10 long rest restores 5 of 10 HD; ink and tattoo unchanged',()=>{const a=longRest({...s,hp:5,hitDice:0,robes:1,deduction:0,ink:2,tattoo:{available:false,minutes:10}});assert.deepEqual([a.hp,a.hitDice,a.robes,a.deduction,a.ink,a.tattoo.available,a.tattoo.minutes],[83,5,5,1,2,false,10]);assert.equal(longRest({...s,hitDice:8}).hitDice,10);});
test('10 · dawn 2 + rolled 3 caps at 4',()=>{assert.equal(dawn({...s,ink:2},3).ink,4);assert.equal(dawn({...s,ink:0},1).ink,1);});
test('11 · End Combat preserves all resources and Focus',()=>{const a={...s,hp:23,robes:1,ink:2,tattoo:{available:false,minutes:0},focus:{name:'Training partner',facts:{AC:'Unknown'},notes:'Observed only'},notes:'Session 12'};const b=enterCombat(a,19);const c=endCombat(b);assert.deepEqual(c,{...b,combat:false});assert.deepEqual([c.hp,c.robes,c.ink,c.tattoo.available,c.focus,c.notes],[23,1,2,false,a.focus,'Session 12']);});
test('12 · initiative raw 1 rerolls once with both dice recorded',()=>{const r=roll({source:'Initiative',kind:'initiative',modifier:7},sequence(1,12));assert.equal(r.total,19);assert.deepEqual([r.dice[0].raw,r.dice[0].replacement],[1,12]);const one=roll({source:'Initiative',kind:'initiative',modifier:7},sequence(1,1));assert.equal(one.total,8);});
test('13 · Unwavering Focus permits hearing non-Focus target',()=>{assert.equal(WORDS.Confound.action,'REACTION');assert.equal(WORDS.Dread.action,'ACTION');assert.ok(WORDS.Confound.trigger.includes('hearing creature within 30 ft'));assert.ok(FEATURES.find(f=>f.name==='Unwavering Focus')!.text.includes('including non-Focus'));const r=roll({source:'Dread',kind:'damage',groups:[{count:2,sides:8,label:'Word'}]},sequence(1,8));assert.equal(r.total,9);assert.equal(r.dice.length,2);assert.equal(r.dice[0].replacement,undefined);});
test('14 · storage round-trip preserves session state regardless of clock',()=>{const mem=new Map<string,string>();const storage={getItem:(k:string)=>mem.get(k)??null,setItem:(k:string,v:string)=>{mem.set(k,v);}};const a={...s,hp:23,robes:1,ink:2,combat:true,round:4,turn:6,reactions:0,notes:'Saved in a previous session',contacts:'Trusted ally',inventory:'3 bolts',focus:{name:'Practice target',facts:{AC:'18'},notes:'Learned from DM'},tattoo:{available:false,minutes:37},effects:[{id:'e',name:'Halt',target:'Target',detail:'speed 0'}],reactionEvents:['1']};const saved=saveState(storage,a);const restored=loadState(storage).state;assert.deepEqual(restored,saved);assert.equal(restored.tattoo.minutes,37);assert.equal(restored.combat,true);});
test('15 · export/import into fresh browser preserves every field',()=>{const a={...s,notes:'台本 · field journal',overrides:{'skill.Stealth':12},history:[roll({source:'Investigation',kind:'skill',modifier:9,groups:[{count:1,sides:8,label:'Intellect'}]},sequence(1,17,5))]};assert.deepEqual(parseSave(JSON.stringify(a)),a);});
test('Lucky handles both d20s before advantage selection; replacement final',()=>{const r=roll({source:'Stealth',kind:'skill',mode:'advantage',modifier:10},sequence(1,1,19));assert.equal(r.total,29);assert.deepEqual(r.dice.map(d=>d.kept),[false,true]);assert.equal(r.dice[0].replacement,1);const r2=roll({source:'Save',kind:'save',mode:'disadvantage',modifier:4},sequence(20,1,12));assert.equal(r2.total,16);});
test('Lucky can be declined; never applies to damage or healing',()=>{assert.equal(roll({source:'check',kind:'ability',lucky:false},sequence(1)).total,1);assert.equal(roll({source:'damage',kind:'damage',groups:[{count:1,sides:8,label:'damage'}]},sequence(1)).total,1);});
test('Only natural 20 attack is critical; checks retain numeric totals',()=>{for(const kind of ['save','skill','initiative','ability'] as const){const r=roll({source:kind,kind,modifier:7},sequence(20));assert.equal(r.critical,false);assert.equal(r.total,27);}assert.equal(roll({source:'Rapier',kind:'attack',modifier:11},sequence(20)).critical,true);});
test('Critical damage doubles dice, never fixed damage modifier',()=>{const r=roll({source:'Critical Rapier + Studied',kind:'damage',groups:[{count:2,sides:8,label:'Rapier'},{count:2,sides:8,label:'Studied Strike'}],modifier:7},sequence(8,8,8,8));assert.equal(r.total,39);assert.equal(r.critical,false);});
test('Multiple Intellect dice on same check apply only highest',()=>{const r=roll({source:'Extraplanar Arcana',kind:'skill',modifier:9,groups:[{count:2,sides:8,label:'Intellect',keepHighest:true}]},sequence(10,3,7));assert.equal(r.total,26);assert.deepEqual(r.dice.map(d=>d.kept),[true,false,true]);});
test('One reaction per event; new event allows second; no third reaction',()=>{const a=spendReaction(s,'one');assert.throws(()=>spendReaction(a,'one'));const b=spendReaction(a,'two');assert.equal(b.reactions,0);assert.throws(()=>spendReaction(b,'three'));assert.equal(startTurn(b).reactions,2);assert.deepEqual(startTurn(b).reactionEvents,[]);});
test('Incapacitated cannot react; initiative loses INT; Focus not auto-cleared',()=>{const a={...s,conditions:['Unconscious'],focus:{name:'Target',facts:{},notes:''}};assert.equal(incapacitated(a),true);assert.equal(derived(a).initiative,2);assert.throws(()=>spendReaction(a,'one'));assert.equal(endCombat(a).focus.name,'Target');});
test('Short rest one roll per die with CON, heal capped, item resources unchanged',()=>{const a={...s,hp:70,hitDice:8,robes:1,ink:2,tattoo:{available:false,minutes:0}};const r=roll({source:'Hit Die',kind:'healing',groups:[{count:1,sides:8,label:'HD'}],modifier:3},sequence(8));const b=shortRest(a,[r,r]);assert.deepEqual([b.hp,b.hitDice,b.robes,b.ink,b.tattoo.available],[83,6,1,2,false]);assert.throws(()=>shortRest({...a,hitDice:0},[r]));});
test('Damage consumes temporary HP first; HP cannot become negative',()=>{const a=applyDamage({...s,hp:12,tempHp:5},10);assert.deepEqual([a.hp,a.tempHp],[7,0]);assert.equal(applyDamage(a,100).hp,0);});
test('Derived overrides survive ability changes',()=>{const a={...s,abilities:{...s.abilities,INT:18},overrides:{ac:23,'save.INT':17,'skill.Stealth':13}};const d=derived(a);assert.equal(d.ac,23);assert.equal(d.saves.INT,17);assert.equal(d.skills.Stealth,13);assert.equal(d.dc,16);assert.equal(d.skills.Arcana,8);assert.equal(weaponStats(a,'Rapier',true).attack,10);});
test('Storage rejects malformed, out-of-range and future-version saves',()=>{assert.throws(()=>parseSave('{'));for(const patch of [{schemaVersion:99},{hp:1000},{ink:-1},{robes:6},{hitDice:11},{combat:'yes'},{abilities:{}},{tattoo:{available:false,minutes:100}},{history:[{}]},{settings:{...s.settings,mode:'loaded dice'}},{overrides:{'__proto__':{hp:100}}}])assert.throws(()=>validateSave({...s,...patch}));});
test('Corrupt storage remains intact and reports recovery error',()=>{const mem=new Map([[STORAGE_KEY,'not json']]);const r=loadState({getItem:k=>mem.get(k)||null});assert.ok(r.error);assert.equal(r.raw,'not json');assert.equal(mem.get(STORAGE_KEY),'not json');});
test('Explicit legacy migration only accepts v0; never resets unknown data',()=>{assert.equal(migrate({schemaVersion:0,hp:23,notes:'old'}).hp,23);assert.equal(migrate({schemaVersion:0,hp:23,notes:'old'}).notes,'old');assert.throws(()=>migrate({schemaVersion:42}));});
test('Crypto sampler produces bounded integers',()=>{for(let i=0;i<1000;i++){const n=randomDie(20);assert.ok(Number.isInteger(n)&&n>=1&&n<=20);}});
test('Invalid injected random values are rejected',()=>{assert.throws(()=>roll({source:'x',kind:'attack'},()=>21));assert.throws(()=>roll({source:'x',kind:'damage',groups:[{count:101,sides:8,label:'x'}]}));});

test('Long rest expires standard temporary HP, End Combat retains them',()=>{const a={...s,tempHp:8};assert.equal(longRest(a).tempHp,0);assert.equal(endCombat(a).tempHp,8);});

test('Ability edits recompute constitution HP but preserve explicit max-HP override',()=>{const a=changeAbility(s,'CON',18);assert.equal(a.maxHp,93);assert.equal(a.hp,83);const b=changeAbility({...s,maxHp:90,overrides:{maxHp:90}},'CON',12);assert.equal(b.maxHp,90);assert.equal(validateSave({...b,maxHp:1500,overrides:{maxHp:1500}}).maxHp,1500);});

test('Level-9 save upgrades once and preserves an automatic backup and session data',()=>{
 const legacy={...s,schemaVersion:1,level:undefined,abilities:{...s.abilities,INT:20},maxHp:75,hp:23,hitDice:0,robes:1,ink:2,combat:true,reactions:0,round:4,notes:'Keep this journal',focus:{name:'Known target',facts:{AC:'18'},notes:'Discovered'},tattoo:{available:false,minutes:17}};
 const raw=JSON.stringify(legacy),mem=new Map([[STORAGE_KEY,raw]]),storage={getItem:(k:string)=>mem.get(k)??null,setItem:(k:string,v:string)=>{mem.set(k,v);}};
 const a=loadState(storage);assert.equal(a.error,undefined);assert.equal(a.state.schemaVersion,4);assert.equal(a.state.level,10);assert.deepEqual([a.state.maxHp,a.state.hp,a.state.hitDice],[83,23,1]);
 for(const key of ['robes','ink','combat','reactions','round','notes','focus','tattoo','history'] as const)assert.deepEqual(a.state[key],legacy[key]);
 assert.equal(mem.get('huang-feng-before-level-10'),raw);assert.deepEqual(loadState(storage).state,a.state);assert.deepEqual(parseSave(raw),a.state);
 const custom=validateSave({...legacy,maxHp:90,overrides:{maxHp:90,'skill.Stealth':12}});assert.equal(custom.maxHp,90);assert.equal(custom.overrides['skill.Stealth'],12);
 const dead=validateSave({...legacy,hp:0,death:{success:1,failure:2}});assert.equal(dead.hp,0);assert.deepEqual(dead.death,{success:1,failure:2});
});
test('Every built-in item save and escape DC tracks the character DC including overrides',()=>{
 for(const dc of [16,17,19]){
  const x={...s,overrides:{dc}},items=itemsFor(x);for(const name of ['Blade of the Scribe +2','Rope of Entanglement']){
   const text=items.find(i=>i.name===name)!.text;assert.match(text,new RegExp('DC '+dc));assert.ok(!text.includes('{dc}'));assert.ok(!text.includes('DC 15'));
  }
  assert.match(featuresFor(x).find(f=>f.name==='Words of Power')!.text,new RegExp('DC '+dc));
  assert.equal(effectText({id:'rope',name:'Restrained · Rope',target:'Enemy',detail:'STR or DEX DC 15 to escape'},dc),`STR or DEX DC ${dc} to escape`);
 }
});
test('New level-10 save exports and imports 10 available Hit Dice',()=>{assert.equal(parseSave(JSON.stringify(s)).hitDice,10);assert.equal(s.schemaVersion,4);assert.equal(s.level,10);});

test('Older v2 saves discard the retired dice setting without changing resources or requiring a Focus name',()=>{
 const saved={...s,hp:23,hitDice:3,robes:1,ink:2,combat:true,notes:'Manual Focus tracking'};
 const restored=parseSave(JSON.stringify({...saved,schemaVersion:2,tomeClearThoughtApplied:undefined,settings:{...saved.settings,potentFocusSum:false}}));
 assert.deepEqual(restored,saved);assert.ok(!('potentFocusSum' in restored.settings));assert.equal(roll(observationSpec(restored,'damage against my Focus'),sequence(3,7)).total,10);
});

test('Tome INT22 recalculates every dependent value with no extra item charges',()=>{
 const d=derived(s);assert.equal(s.abilities.INT,22);assert.equal(d.m.INT,6);assert.deepEqual([d.ac,d.initiative,d.dc],[21,8,18]);
 assert.deepEqual(d.saves,{STR:5,DEX:8,CON:9,INT:16,WIS:10,CHA:5});
 for(const skill of ['Arcana','Religion','Investigation','History'])assert.equal(d.skills[skill],10);
 assert.equal(d.skills.Nature,6);assert.equal(10+d.skills.Investigation,20);assert.equal(d.pb,4);assert.equal(d.intellect,8);
 assert.deepEqual([s.hp,s.maxHp,s.hitDice,s.robes,s.ink,s.reactions],[83,83,10,5,4,2]);
 const robes=itemsFor(s).find(i=>i.name==='Doctoral Robes')!.text;assert.match(robes,/add \+6 \(INT\)/);assert.doesNotMatch(robes,/add \+5/);
 assert.match(featuresFor(s).find(f=>f.name==='Keen Awareness')!.text,/d20 \+ 8/);
 for(const name of ['Blade of the Scribe +2','Rope of Entanglement'])assert.match(itemsFor(s).find(i=>i.name===name)!.text,/DC 18/);
});
test('The Tome migration backs up schema-v2 and is idempotent without rest, healing or rewriting history',()=>{
 const history=[roll({source:'Before Tome',kind:'save',modifier:14,groups:[{count:1,sides:8,label:'Sharp Mind'}]},sequence(12,3))];
 const old={...s,schemaVersion:2,tomeClearThoughtApplied:undefined,abilities:{...s.abilities,INT:20},hp:23,tempHp:7,hitDice:2,robes:1,ink:2,reactions:0,combat:true,initiative:19,round:6,death:{success:1,failure:2},tattoo:{available:false,minutes:17},notes:'Keep journal',contacts:'Keep contacts',inventory:'My custom equipment',focus:{name:'Known target',facts:{AC:'18'},notes:'Keep Focus notes'},history,overrides:{maxHp:83,'skill.Stealth':12}};
 const raw=JSON.stringify(old),mem=new Map([[STORAGE_KEY,raw]]),storage={getItem:(k:string)=>mem.get(k)??null,setItem:(k:string,v:string)=>{mem.set(k,v);}};
 const first=loadState(storage);assert.equal(first.error,undefined);assert.equal(first.state.schemaVersion,4);assert.equal(first.state.tomeClearThoughtApplied,true);assert.equal(first.state.abilities.INT,22);
 for(const key of ['hp','tempHp','hitDice','robes','ink','reactions','combat','initiative','round','death','tattoo','notes','contacts','focus','history','overrides'] as const)assert.deepEqual(first.state[key],old[key]);
 assert.ok(first.state.inventory.startsWith(old.inventory));assert.match(first.state.inventory,/Tome of Clear Thought/);assert.equal(mem.get('huang-feng-before-int22'),raw);assert.deepEqual(loadState(storage).state,first.state);assert.deepEqual(parseSave(raw),first.state);
 assert.equal(first.state.inventory.match(/Tome of Clear Thought/g)?.length,1);
 const already=validateSave({...old,abilities:{...s.abilities,INT:22},inventory:'Tome of Clear Thought (already studied)'});assert.equal(already.abilities.INT,22);assert.equal(already.inventory.split('\n')[0],'Tome of Clear Thought (already studied)');assert.equal(already.inventory.match(/Tome of Clear Thought/g)?.length,1);
 assert.equal(validateSave({...old,abilities:{...s.abilities,INT:24}}).abilities.INT,24);
});
test('Schema-v3 roundtrip retains subsequent manual edits instead of applying the Tome again',()=>{
 const edited=changeAbility(s,'INT',18);assert.equal(parseSave(JSON.stringify(edited)).abilities.INT,18);assert.equal(parseSave(JSON.stringify(s)).tomeClearThoughtApplied,true);
 assert.throws(()=>validateSave({...s,tomeClearThoughtApplied:false}));
});

test('Spiderbite uses dagger stats without an invented magic bonus; off-hand omits only positive ability damage',()=>{
 assert.deepEqual([weaponStats(s,'Spiderbite Daggers',true).attack,weaponStats(s,'Spiderbite Daggers',true).damage,weaponStats(s,'Spiderbite Daggers',true).sides],[10,6,4]);
 assert.deepEqual([weaponStats(s,'Spiderbite Daggers',false).attack,weaponStats(s,'Spiderbite Daggers',false).damage],[6,2]);
 for(const focus of [true,false])assert.equal(weaponStats(s,'Spiderbite Daggers',focus,true).damage,0);
 assert.equal(weaponStats(s,'Spiderbite Daggers',true,true).attack,10);
 const weak={...s,abilities:{...s.abilities,INT:8}};assert.equal(weaponStats(weak,'Spiderbite Daggers',true,true).damage,-1);
 assert.equal(weaponStats(s,'Rapier',true).attack,12);assert.equal(weaponStats(s,'Rapier',true).damage,8);
});
test('Spiderbite poison requires both hits, rolls separate2d4 without Lucky/critical doubling, and follows item DC',()=>{
 assert.throws(()=>spiderbitePoisonSpec(s,'Target',false));
 const spec=spiderbitePoisonSpec(s,'Target',true);assert.match(spec.source,/CON DC 18/);assert.deepEqual(spec.groups,[{count:2,sides:4,label:'Poison'}]);
 const poison=roll(spec,sequence(1,1));assert.equal(poison.total,2);assert.equal(poison.dice.length,2);assert.equal(poison.critical,false);assert.ok(poison.dice.every(d=>d.replacement===undefined));
 assert.match(spiderbitePoisonSpec({...s,overrides:{dc:19}},'',true).source,/CON DC 19/);
});
test('Spiderbite replaces only the ordinary inventory dagger and migrates its overrides once',()=>{
 const old={...s,schemaVersion:3,spiderbiteDaggersEquipped:undefined,hp:23,ink:2,robes:1,reactions:0,combat:true,notes:'Keep notes',inventory:'Rope\nDagger\nDagger +1 (stored)\n3 bolts',overrides:{'attack.Dagger.focus':13,'damage.Dagger.other':3,ac:23}};
 const raw=JSON.stringify(old),mem=new Map([[STORAGE_KEY,raw]]),storage={getItem:(k:string)=>mem.get(k)??null,setItem:(k:string,v:string)=>{mem.set(k,v);}};
 const a=loadState(storage);assert.equal(a.error,undefined);assert.equal(a.state.schemaVersion,4);assert.equal(a.state.spiderbiteDaggersEquipped,true);assert.ok(!a.state.inventory.split('\n').includes('Dagger'));assert.match(a.state.inventory,/Dagger \+1 \(stored\)/);assert.match(a.state.inventory,/Spiderbite Daggers \(pair\)/);assert.deepEqual(a.state.overrides,{'attack.Spiderbite Daggers.focus':13,'damage.Spiderbite Daggers.other':3,ac:23});
 for(const key of ['hp','ink','robes','reactions','combat','notes','abilities','focus','history'] as const)assert.deepEqual(a.state[key],old[key]);
 assert.equal(mem.get('huang-feng-before-spiderbite'),raw);assert.deepEqual(loadState(storage).state,a.state);assert.deepEqual(parseSave(raw),a.state);assert.equal(equipSpiderbiteDaggers(a.state).inventory,a.state.inventory);
 const edited=changeAbility(a.state,'INT',18);assert.equal(parseSave(JSON.stringify(edited)).abilities.INT,18);assert.throws(()=>validateSave({...s,spiderbiteDaggersEquipped:false}));
});
