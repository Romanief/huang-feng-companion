import type {SVGProps} from 'react';
type Props=SVGProps<SVGSVGElement>&{size?:number};
const shapes:Record<string,string>={
 heart:'M2 3h4v2h4V3h4v2h2v5h-2v2h-2v2h-2v2H8v-2H6v-2H4v-2H2V8H0V5h2z',
 shield:'M2 1h12v2h2v6h-2v3h-2v2h-2v2H6v-2H4v-2H2V9H0V3h2z M4 4v5h2v3h4v-3h2V4z',
 dice:'M6 0h4v2h4v2h2v8h-2v2h-4v2H6v-2H2v-2H0V4h2V2h4z M6 2v2H4v2h2V4h4v2h2V4h-2V2z M2 6v4h2V6z M12 6v4h2V6z M6 6v4h4V6z M4 10v2h2v2h4v-2h2v-2h-2v2H6v-2z',
 sword:'M12 0h4v4h-2v2h-2v2h-2v2H8v2h2v2H8v-2H6v2H4v2H0v-4h2v-2h2V8H2V6h2v2h2V6h2V4h2V2h2z',
 book:'M0 1h6v2h4V1h6v13h-6v2H6v-2H0z M2 3v9h4V5H4V3z M10 5v7h4V3h-2v2z',
 scroll:'M3 0h10v2h2v3h-2V2H5v10h8v2h-2v2H1v-2H0v-3h2v3h7v-2H3z M7 4h4v2H7z M7 8h4v2H7z',
 target:'M4 0h8v2h2v2h2v8h-2v2h-2v2H4v-2H2v-2H0V4h2V2h2z M4 4v8h8V4z M6 6h4v4H6z',
 save:'M0 0h12v2h4v14H0z M3 2v4h7V2z M3 10v4h10v-4z',
 check:'M12 2h4v4h-2v2h-2v2h-2v2H8v2H4v-2H2v-2H0V6h4v2h2v2h2V8h2V6h2z',
 close:'M0 0h4v2h2v2h4V2h2V0h4v4h-2v2h-2v4h2v2h2v4h-4v-2h-2v-2H6v2H4v2H0v-4h2v-2h2V6H2V4H0z',
 plus:'M6 0h4v6h6v4h-6v6H6v-6H0V6h6z',
 minus:'M0 6h16v4H0z',
 arrow:'M4 0h12v12h-4V6h-2v2H8v2H6v2H4v2H0v-4h2V8h2V6h2V4H4z',
 boots:'M4 0h8v8h2v2h2v4H0v-4h2V8h2z',
 brain:'M4 0h8v2h2v2h2v6h-2v2h-2v4H4v-4H2v-2H0V4h2V2h2z M4 4v4h2V4z M10 4v4h2V4z M6 10v2h4v-2z',
 moon:'M6 0h6v2H8v2H6v6h2v2h6v-2h2v4h-4v2H4v-2H2v-2H0V4h2V2h4z',
 sun:'M6 0h4v2H6z M0 6h2v4H0z M14 6h2v4h-2z M6 14h4v2H6z M4 4h8v8H4z M2 2h2v2H2z M12 2h2v2h-2z M2 12h2v2H2z M12 12h2v2h-2z',
 sound:'M6 2h4v12H6v-2H4v-2H0V6h4V4h2z M12 4h2v2h2v4h-2v2h-2v-2h2V6h-2z',
 mute:'M6 2h4v12H6v-2H4v-2H0V6h4V4h2z M12 5h2v2h2v2h-2v2h-2V9h2V7h-2z',
 history:'M4 0h8v2h2v2h2v8h-2v2h-2v2H4v-2H2v-2H0v-2h4v2h2v2h4v-2h2V4h-2V2H6v2H4v2h2v2H0V2h2v2h2z M7 4h2v4h3v2H7z',
 feather:'M10 0h6v6h-2v2h-2v2h-2v2H8v2H6v2H2v-4h2v-2h2V8h2V4h2z',
 wifi:'M4 2h8v2h2v2h2v2h-2V6h-2V4H4v2H2v2H0V6h2V4h2z M6 8h4v2h2v2h-2v-2H6v2H4v-2h2z M7 14h2v2H7z',
 gear:'M6 0h4v2h2V0h2v4h2v2h-2v4h2v2h-4v4h-2v-2H6v2H4v-4H0v-2h2V6H0V4h2V0h2v2h2z M6 6v4h4V6z',
};
function icon(name:string){return function PixelIcon({size=20,...props}:Props){return <svg {...props} className={`pixel-icon ${props.className||''}`} width={size} height={size} viewBox="0 0 16 16" fill="currentColor" fillRule="evenodd" shapeRendering="crispEdges" aria-hidden="true" focusable="false"><path d={shapes[name]||shapes.dice}/></svg>;};}
export const Heart=icon('heart'), Shield=icon('shield'), Dices=icon('dice'), Swords=icon('sword'), BookOpen=icon('book'), ScrollText=icon('scroll'), Target=icon('target'), Download=icon('save'), Check=icon('check'), CheckCircle2=icon('check'), X=icon('close'), Plus=icon('plus'), Minus=icon('minus'), ArrowUpRight=icon('arrow'), Footprints=icon('boots'), Brain=icon('brain'), Moon=icon('moon'), Sun=icon('sun'), Volume2=icon('sound'), VolumeX=icon('mute'), History=icon('history'), RotateCcw=icon('history'), Feather=icon('feather'), WifiOff=icon('wifi'), Settings2=icon('gear'), Compass=icon('target');
